// // =============================================================================
// // import 'package:thingsboard_client/thingsboard_client.dart';
// //
// // main() async {
// //   try {
// //     var tbClient = ThingsboardClient('http://phyclouds.com:8080');
// //     await tbClient.login(LoginRequest('tenantdemo@thingsboard.org', 'tenant'));
// //     print("logined");
// //     print('isAuthenticated=${tbClient.isAuthenticated()}');
// //
// //     print('authUser: ${tbClient.getAuthUser()}');
// //
// //     var currentUserDetails = await tbClient.getUserService().getUser();
// //     print('currentUserDetails: $currentUserDetails');
// //
// //     await tbClient.logout();
// //
// //   } catch (e, s) {
// //     print('Error: $e');
// //     print('Stack: $s');
// //   }
// // }
//
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:collection/collection.dart';
// import 'package:thingsboard_client/src/error/thingsboard_error.dart';
// import 'package:thingsboard_client/src/http/http_utils.dart';
// import 'package:thingsboard_client/src/model/alarm_models.dart';
// import 'package:thingsboard_client/src/model/asset_models.dart';
// import 'package:thingsboard_client/src/model/customer_models.dart';
// import 'package:thingsboard_client/src/model/dashboard_models.dart';
// import 'package:thingsboard_client/src/model/device_models.dart';
// import 'package:thingsboard_client/src/model/entity_type_models.dart';
// import 'package:thingsboard_client/src/model/id/entity_id.dart';
// import 'package:thingsboard_client/src/model/login_models.dart';
// import 'package:thingsboard_client/src/model/page/page_data.dart';
// import 'package:thingsboard_client/src/model/page/page_link.dart';
// import 'package:thingsboard_client/src/model/page/sort_order.dart';
// import 'package:thingsboard_client/src/model/query/query_models.dart';
// import 'package:thingsboard_client/src/model/relation_models.dart';
// import 'package:thingsboard_client/src/model/telemetry_models.dart';
// import 'package:thingsboard_client/src/model/two_factor_auth_models.dart';
// import 'package:thingsboard_client/src/model/user_models.dart';
// import 'package:thingsboard_client/src/service/asset_service.dart';
// import 'package:thingsboard_client/src/service/device_service.dart';
// import 'package:thingsboard_client/src/thingsboard_client_base.dart';
import 'Thingsboard/src/error/thingsboard_error.dart';
import 'Thingsboard/src/http/http_utils.dart';
import 'Thingsboard/src/model/alarm_models.dart';
import 'Thingsboard/src/model/asset_models.dart';
import 'Thingsboard/src/model/customer_models.dart';
import 'Thingsboard/src/model/dashboard_models.dart';
import 'Thingsboard/src/model/device_models.dart';
import 'Thingsboard/src/model/entity_type_models.dart';
import 'Thingsboard/src/model/id/entity_id.dart';
import 'Thingsboard/src/model/login_models.dart';
import 'Thingsboard/src/model/page/page_data.dart';
import 'Thingsboard/src/model/page/page_link.dart';
import 'Thingsboard/src/model/page/sort_order.dart';
import 'Thingsboard/src/model/query/query_models.dart';
import 'Thingsboard/src/model/relation_models.dart';
import 'Thingsboard/src/model/telemetry_models.dart';
import 'Thingsboard/src/model/two_factor_auth_models.dart';
import 'Thingsboard/src/model/user_models.dart';
import 'Thingsboard/src/service/asset_service.dart';
import 'Thingsboard/src/service/device_service.dart';
import 'Thingsboard/src/thingsboard_client_base.dart';

//13 cases
void main() async {
  print("Welcome to the Thingsboard menu!");

  while (true) {
    // ThingsBoard REST API URL
    const thingsBoardApiEndpoint = 'http://phyclouds.com:8080';
    const String relationType = 'Contains';

    print("\nPlease select an option:");
    print("1.  •ADD DEVICE");
    print("2.  •REMOVE DEVICE");
    print("3.  •ADD ASSETS");
    print("4.  •REMOVE ASSETS");
    print("5.  •CONTROL DEVICE");
    print("6.  •CREATE A RELATION BETWEEN ASSETS");
    print("7.  •CREATING DASHBOARD");
    print("8.  •CREATING WEDIGETS IN DASHBOARD WITH DIFFERENT WAY(USER INPUT FOR TITLE)");
    print("9.  •CREATING WEDIGETS IN DASHBOARD FOR SWITCHES (USER INPUT FOR TITLE)");
    print("10. •List Of Devices");
    print("11. •List Of Alarms");
    print("12. •Create new customer");
    print("13. •Exit");

    var input = stdin.readLineSync();
    var choice = int.tryParse(input!);

    if (choice != null) {
      switch (choice) {
        case 1:
          print("You selected Option 1");
          // Perform the action for Option 1
          try {
            // Create instance of ThingsBoard API Client
            var tbClient = ThingsboardClient(thingsBoardApiEndpoint);

            // Perform login with default Tenant Administrator credentials
            await tbClient
                .login(LoginRequest('tenantdemo@thingsboard.org', 'tenant'));
            print("Tenant Login in Thingsboard.");

            print("ENTER Name for Device:-");
            // var deviceName = 'phytec11';
            var deviceName = stdin.readLineSync();

            // Construct device object
            var device = Device(deviceName!, 'MqttDevice');
            device.additionalInfo = {'description': 'My test device!'};

            // Add device
            var savedDevice =
            await tbClient.getDeviceService().saveDevice(device);
            print('savedDevice: $savedDevice');

            // Create entity filter to get device by its name
            // var entityFilter = EntityNameFilter(
            //     entityType: EntityType.DEVICE, entityNameFilter: deviceName);

            // Prepare list of queried device fields
            // var deviceFields = <EntityKey>[
            //   EntityKey(type: EntityKeyType.ENTITY_FIELD, key: 'dart1'),
            //   EntityKey(type: EntityKeyType.ENTITY_FIELD, key: 'SwitchS'),
            //   EntityKey(type: EntityKeyType.ENTITY_FIELD, key: 'createdTime')
            // ];

            // Prepare list of queried device timeseries
            // var deviceTelemetry = <EntityKey>[
            //   EntityKey(type: EntityKeyType.TIME_SERIES, key: 'temperature'),
            //   EntityKey(type: EntityKeyType.TIME_SERIES, key: 'humidity')
            // ];

            // Create entity query with provided entity filter, queried fields and page link
            // var devicesQuery = EntityDataQuery(
            //     entityFilter: entityFilter,
            //     entityFields: deviceFields,
            // latestValues: deviceTelemetry,
            // pageLink: EntityDataPageLink(
            //     pageSize: 10,
            //     sortOrder: EntityDataSortOrder(
            //         key: EntityKey(
            //             type: EntityKeyType.ENTITY_FIELD, key: 'createdTime'),
            //         direction: EntityDataSortOrderDirection.DESC)));

            // Create timeseries subscription command to get data for 'temperature' and 'humidity' keys for last hour with realtime updates
            // var currentTime = DateTime.now().millisecondsSinceEpoch;
            // var timeWindow = Duration(hours: 1).inMilliseconds;
            //
            // var tsCmd = TimeSeriesCmd(
            //     keys: ['temperature', 'humidity'],
            //     startTs: currentTime - timeWindow,
            //     timeWindow: timeWindow);
            //
            // Create subscription command with entities query and timeseries subscription
            // var cmd = EntityDataCmd(query: devicesQuery, tsCmd: tsCmd);

            // Create subscription with provided subscription command
            // var telemetryService = tbClient.getTelemetryService();
            // var subscription = TelemetrySubscriber(telemetryService, [cmd]);

            // Create listener to get data updates from WebSocket
            // subscription.entityDataStream.listen((entityDataUpdate) {
            //   print('Received entity data update: $entityDataUpdate');
            // });

            // Perform subscribe (send subscription command via WebSocket API and listen for responses)
            // subscription.subscribe();

            // Post sample telemetry
            // var rng = Random();
            // for (var i = 0; i < 5; i++) {
            //   await Future.delayed(Duration(seconds: 2));
            //   var temperature = 10 + 20 * rng.nextDouble();
            //   var humidity = 30 + 40 * rng.nextDouble();
            //   var telemetryRequest = {'temperature': temperature, 'humidity': humidity};
            //   print('Save telemetry request: $telemetryRequest');
            //   var res = await tbClient
            //       .getAttributeService()
            //       .saveEntityTelemetry(savedDevice.id!, 'TELEMETRY', telemetryRequest);
            //   print('Save telemetry result: $res');
            // }

            // Wait few seconds to show data updates are received by subscription listener
            // await Future.delayed(Duration(seconds: 2));

            // Finally unsubscribe to release subscription
            // subscription.unsubscribe();

            // Delete the device
            // await tbClient.getDeviceService().deleteDevice(savedDevice.id!.id!);

            // Finally perform logout to clear credentials
            await tbClient.logout();
          } catch (e, s) {
            print('Error: $e');
            print('Stack: $s');
          }
          break;
// ------------------------------------- CASE-2 -------------------------------------
        case 2:
          print("You selected Option 2");
          // Perform the action for Option 2
          // Create instance of ThingsBoard API Client
          var tbClient = ThingsboardClient(thingsBoardApiEndpoint);

          // Perform login with default Tenant Administrator credentials
          await tbClient
              .login(LoginRequest('tenantdemo@thingsboard.org', 'tenant'));
          print("Tenant Login in Thingsboard.");

          // Create a device service instance
          final DeviceService deviceService = DeviceService(tbClient);

          // Specify the device id to delete
          final String deviceId = '86b86dc0-e400-11ed-ae74-db5ae19db63f';

          try {
            // Delete the device
            await deviceService.deleteDevice(deviceId);
            print('Device $deviceId has been deleted successfully!');
          } catch (e) {
            print('Error occurred while deleting device: $e');
          }
          break;
// ------------------------------------- CASE-3 -------------------------------------
        case 3:
          print("You selected Option 3");
          // Perform the action for Option 3
          try {
            // Create instance of ThingsBoard API Client
            var tbClient = ThingsboardClient(thingsBoardApiEndpoint);

            // Perform login with default Tenant Administrator credentials
            await tbClient
                .login(LoginRequest('tenantdemo@thingsboard.org', 'tenant'));
            print("Tenant Login in Thingsboard.");

            // var deviceName = 'phytec11';
            var assetsName = stdin.readLineSync();

            // Construct device object
            var assets = Asset(assetsName!, 'default');
            assets.additionalInfo = {'description': 'My test device!'};

            // Add device
            var savedAssets =
            await tbClient.getAssetService().saveAsset(assets);
            print('savedDevice: $savedAssets');

            // Create entity filter to get device by its name
            var entityFilter = EntityNameFilter(
                entityType: EntityType.ASSET, entityNameFilter: assetsName);

            // Prepare list of queried device fields
            var assetsFields = <EntityKey>[
              EntityKey(type: EntityKeyType.ENTITY_FIELD, key: 'dart1'),
              EntityKey(type: EntityKeyType.ENTITY_FIELD, key: 'SwitchS'),
              EntityKey(type: EntityKeyType.ENTITY_FIELD, key: 'createdTime')
            ];

            // Prepare list of queried device timeseries
            var assetsTelemetry = <EntityKey>[
              EntityKey(type: EntityKeyType.TIME_SERIES, key: 'temperature'),
              EntityKey(type: EntityKeyType.TIME_SERIES, key: 'humidity')
            ];

            // Create entity query with provided entity filter, queried fields and page link
            var assetsQuery = EntityDataQuery(
                entityFilter: entityFilter,
                entityFields: assetsFields,
                latestValues: assetsTelemetry,
                pageLink: EntityDataPageLink(
                    pageSize: 10,
                    sortOrder: EntityDataSortOrder(
                        key: EntityKey(
                            type: EntityKeyType.ENTITY_FIELD,
                            key: 'createdTime'),
                        direction: EntityDataSortOrderDirection.DESC)));

            // Create timeseries subscription command to get data for 'temperature' and 'humidity' keys for last hour with realtime updates
            var currentTime = DateTime.now().millisecondsSinceEpoch;
            var timeWindow = Duration(hours: 1).inMilliseconds;

            var tsCmd = TimeSeriesCmd(
                keys: ['temperature', 'humidity'],
                startTs: currentTime - timeWindow,
                timeWindow: timeWindow);

            // Create subscription command with entities query and timeseries subscription
            var cmd = EntityDataCmd(query: assetsQuery, tsCmd: tsCmd);

            // Create subscription with provided subscription command
            var telemetryService = tbClient.getTelemetryService();
            var subscription = TelemetrySubscriber(telemetryService, [cmd]);

            // Create listener to get data updates from WebSocket
            subscription.entityDataStream.listen((entityDataUpdate) {
              print('Received entity data update: $entityDataUpdate');
            });

            // Perform subscribe (send subscription command via WebSocket API and listen for responses)
            subscription.subscribe();

            // Post sample telemetry
            var rng = Random();
            for (var i = 0; i < 5; i++) {
              await Future.delayed(Duration(seconds: 2));
              var temperature = 10 + 20 * rng.nextDouble();
              var humidity = 30 + 40 * rng.nextDouble();
              var telemetryRequest = {
                'temperature': temperature,
                'humidity': humidity
              };
              print('Save telemetry request: $telemetryRequest');
              var res = await tbClient
                  .getAttributeService()
                  .saveEntityTelemetry(
                  savedAssets.id!, 'TELEMETRY', telemetryRequest);
              print('Save telemetry result: $res');
            }

            // Wait few seconds to show data updates are received by subscription listener
            await Future.delayed(Duration(seconds: 2));

            // Finally unsubscribe to release subscription
            subscription.unsubscribe();

            // Delete the device
            // await tbClient.getDeviceService().deleteDevice(savedDevice.id!.id!);

            // Finally perform logout to clear credentials
            await tbClient.logout();
          } catch (e, s) {
            print('Error: $e');
            print('Stack: $s');
          }
          break;
// ------------------------------------- CASE-4 -------------------------------------
        case 4:
          print("You selected Option 4");
          // Perform the action for Option 1
          // // Connect to the Thingsboard server
          // final client = ThingsboardClient('demo.thingsboard.io');
          // await client.connect();

          // Create instance of ThingsBoard API Client
          var tbClient = ThingsboardClient(thingsBoardApiEndpoint);

          // Perform login with default Tenant Administrator credentials
          await tbClient
              .login(LoginRequest('tenantdemo@thingsboard.org', 'tenant'));
          print("Tenant Login in Thingsboard.");

          // Create a device service instance
          final AssetService assetsService = AssetService(tbClient);

          // Specify the device id to delete
          final String assetId = '22dc5840-e417-11ed-ae74-db5ae19db63f';

          try {
            // Delete the device
            await assetsService.deleteAsset(assetId);
            // await deviceService.deleteDevice(deviceId);
            print('Device $assetId has been deleted successfully!');
          } catch (e) {
            print('Error occurred while deleting device: $e');
          }
          break;
// ------------------------------------- CASE-5 -------------------------------------
        case 5:
          print("You selected Option 5");
          // Perform the action for Option 2
          try {
            // Create instance of ThingsBoard API Client
            var tbClient = ThingsboardClient(thingsBoardApiEndpoint);

            // Perform login with default Tenant Administrator credentials
            await tbClient
                .login(LoginRequest('tenantdemo@thingsboard.org', 'tenant'));
            print("Tenant Login in Thingsboard.");

            // var deviceName = 'phytec11';
            var deviceName = stdin.readLineSync();

            // Construct device object
            var device = Device(deviceName!, 'MqttDevice');
            device.additionalInfo = {'description': 'My test device!'};

            // Add device
            var savedDevice =
            await tbClient.getDeviceService().saveDevice(device);
            print('savedDevice: $savedDevice');

            // Create entity filter to get device by its name
            var entityFilter = EntityNameFilter(
                entityType: EntityType.DEVICE, entityNameFilter: deviceName);

            // Prepare list of queried device fields
            var deviceFields = <EntityKey>[
              EntityKey(type: EntityKeyType.ENTITY_FIELD, key: 'dart1'),
              EntityKey(type: EntityKeyType.ENTITY_FIELD, key: 'SwitchS'),
              EntityKey(type: EntityKeyType.ENTITY_FIELD, key: 'createdTime')
            ];

            // Create entity query with provided entity filter, queried fields and page link
            var devicesQuery = EntityDataQuery(
                entityFilter: entityFilter,
                entityFields: deviceFields,
                pageLink: EntityDataPageLink(
                    pageSize: 10,
                    sortOrder: EntityDataSortOrder(
                        key: EntityKey(
                            type: EntityKeyType.ENTITY_FIELD,
                            key: 'createdTime'),
                        direction: EntityDataSortOrderDirection.DESC)));

            // Create timeseries subscription command to get data for 'temperature' and 'humidity' keys for last hour with realtime updates
            var currentTime = DateTime.now().millisecondsSinceEpoch;
            var timeWindow = Duration(hours: 1).inMilliseconds;

            var tsCmd = TimeSeriesCmd(
                keys: ['Switch'],
                startTs: currentTime - timeWindow,
                timeWindow: timeWindow);
            // Create subscription command with entities query and timeseries subscription
            var cmd = EntityDataCmd(query: devicesQuery, tsCmd: tsCmd);

            // Create subscription with provided subscription command
            var telemetryService = tbClient.getTelemetryService();

            var subscription = TelemetrySubscriber(telemetryService, [cmd]);
            // Create listener to get data updates from WebSocket
            subscription.entityDataStream.listen((entityDataUpdate) {
              print('Received entity data update: $entityDataUpdate');
            });
            // Perform subscribe (send subscription command via WebSocket API and listen for responses)
            subscription.subscribe();

            // Post sample telemetry
            var rng = Random();
            while (true) {
              print("ENTER- ON or OFF");
              var camd = stdin.readLineSync();
              if (camd == "ON") {
                for (var i = 0; i < 5; i++) {
                  await Future.delayed(Duration(seconds: 2));
                  var SwitchON = 'ON';
                  var telemetryRequest = {'Switch': SwitchON};
                  print('Save telemetry request: $telemetryRequest');
                  var res = await tbClient
                      .getAttributeService()
                      .saveEntityTelemetry(
                      savedDevice.id!, 'TELEMETRY', telemetryRequest);
                  // var rpcRequest = {'Switch': SwitchON};
                  // print('Save RPC request: $rpcRequest');
                  // var res = await tbClient
                  //     .getAttributeService()
                  //     .saveEntityTelemetry(
                  //     savedDevice.id!, 'RPC', rpcRequest);
                  print('Save telemetry result: $res');
                }
                // Wait few seconds to show data updates are received by subscription listener
                await Future.delayed(Duration(seconds: 2));
              } else {
                for (var i = 0; i < 5; i++) {
                  await Future.delayed(Duration(seconds: 2));
                  var SwitchOFF = 'OFF';
                  var telemetryRequest = {'Switch': SwitchOFF};
                  print('Save telemetry request: $telemetryRequest');
                  var res = await tbClient
                      .getAttributeService()
                      .saveEntityTelemetry(
                      savedDevice.id!, 'TELEMETRY', telemetryRequest);
                  print('Save telemetry result: $res');
                }
                // Wait few seconds to show data updates are received by subscription listener
                await Future.delayed(Duration(seconds: 2));
              }
              break;
            }
            // Finally perform logout to clear credentials
          } catch (e, s) {
            print('Error: $e');
            print('Stack: $s');
          }
          break;
// ------------------------------------- CASE-6 -------------------------------------
        case 6:
          print("You selected Option 6");
          // Perform the action for Option 3
          try {
            // Create instance of ThingsBoard API Client
            var tbClient = ThingsboardClient(thingsBoardApiEndpoint);

            // Perform login with default Tenant Administrator credentials
            await tbClient
                .login(LoginRequest('tenantdemo@thingsboard.org', 'tenant'));
            print("Tenant Login in Thingsboard.");

            // String uuid1 = '4fd5ffb0-e8b6-11ed-ae74-db5ae19db63f';
            // String uuid2 = '37a9f310-e8b6-11ed-ae74-db5ae19db63f';
            await Future.delayed(Duration(seconds: 2));
            Map<String, String> type1 = {
              "type": "Contains",
              "entityType": "ASSET",
              "id": "4fd5ffb0-e8b6-11ed-ae74-db5ae19db63f"
            };
            Map<String, String> type2 = {
              "type": "Contains",
              "entityType": "ASSET",
              "id": "37a9f310-e8b6-11ed-ae74-db5ae19db63f"
            };

            print('make a relation');
            var from = EntityId.fromJson(type1);
            var to = EntityId.fromJson(type2);
            var assetRelation = EntityRelation(from: from, to: to);

            await tbClient
                .getEntityRelationService()
                .saveRelation(assetRelation);
            await Future.delayed(Duration(seconds: 2));
            print('work is done');

            await tbClient.logout();
          } catch (e, s) {
            print('Error: $e');
            print('Stack: $s');
          }
          break;
// ------------------------------------- CASE-7 -------------------------------------
        case 7:
          print("You selected Option 7");
          // Perform the action for Option 1
          importDashboard();
          break;
// ------------------------------------- CASE-8 -------------------------------------
        case 8:
          print("You selected Option 8");
          // Perform the action for Option 2
          String filePath =
              'C:/Users/Admin/AndroidStudioProjects/thingsboard_simulation/lib/home.json'; // Replace with the actual file path

          // Read the JSON file
          Map<String, dynamic> jsonData = await readJsonFile(filePath);

          // Get user input for the new title
          print('Enter the new title:');
          String? newTitle = stdin.readLineSync();

          // Modify the title in the JSON data
          jsonData['title'] = newTitle;

          // Write the updated JSON data back to the file
          await writeJsonFile(filePath, jsonData);

          print('Title updated successfully.');

          // Create widgets in dashboard
          importDashboard2();

          break;
// ------------------------------------- CASE-9 -------------------------------------
        case 9:
          print("You selected Option 9");
          // Perform the action for Option 2
          importDashboard3();
          break;
// ------------------------------------- CASE-10 -------------------------------------
        case 10:
          print("You selected Option 10");
          try {
            tbClient = ThingsboardClient(thingsBoardApiEndpoint);
            // Perform login with default Tenant Administrator credentials
            await tbClient
                .login(LoginRequest('tenantdemo@thingsboard.org', 'tenant'));
            await fetchTenantDevicesExample();

            // tbClient = ThingsboardClient(thingsBoardApiEndpoint,
            //     storage: InMemoryStorage(),
            //     onUserLoaded: onUserLoaded,
            //     onMfaAuth: onMfa,
            //     onError: onError,
            //     onLoadStarted: onLoadStarted,
            //     onLoadFinished: onLoadFinished
            // );
            await tbClient.init();
          } catch (e, s) {
            print('Error: $e');
            print('Stack: $s');
          }
          break;

// ------------------------------------- CASE-11 -------------------------------------
        case 11:
          print("You selected Option 11");

          try {
            tbClient = ThingsboardClient(thingsBoardApiEndpoint);
            // Perform login with default Tenant Administrator credentials
            await tbClient
                .login(LoginRequest('tenantdemo@thingsboard.org', 'tenant'));
            await onUserLoaded();

            // tbClient = ThingsboardClient(thingsBoardApiEndpoint,
            //     storage: InMemoryStorage(),
            //     onUserLoaded: onUserLoaded,
            //     onMfaAuth: onMfa,
            //     onError: onError,
            //     onLoadStarted: onLoadStarted,
            //     onLoadFinished: onLoadFinished
            // );
            await tbClient.init();
          } catch (e, s) {
            print('Error: $e');
            print('Stack: $s');
          }
          break;

// ------------------------------------- CASE-12 -------------------------------------
        case 12:
          print("You selected Option 1");
          // Perform the action for Option 1
          try {
            // Create instance of ThingsBoard API Client
            var tbClient = ThingsboardClient(thingsBoardApiEndpoint);

            // Perform login with default Tenant Administrator credentials
            await tbClient
                .login(LoginRequest('tenantdemo@thingsboard.org', 'tenant'));
            print("Tenant Login in Thingsboard.");

            print("ENTER Name for Device:-");
            // var deviceName = 'phytec11';
            var deviceName = stdin.readLineSync();

            // Construct device object
            var device = Customer(deviceName!);
            device.additionalInfo = {'description': 'My test device!'};

            // Add device
            var savedDevice =
            await tbClient.getCustomerService().saveCustomer(device);
            print('savedDevice: $savedDevice');
          } catch (e, s) {
            print('Error: $e');
            print('Stack: $s');
          }
          break;
// ------------------------------------- CASE-13 -------------------------------------
        case 13:
          print("Exiting the menu...");
          return;

        default:
          print("Invalid choice. Please try again.");
      }
    } else {
      print("Invalid input. Please enter a valid number.");
    }
  }
}

// void onError(ThingsboardError error) {
//   print('onError: error=$error');
// }

// void onLoadStarted() {
//   print('ON LOAD STARTED!');
// }
//
// void onLoadFinished() {
//   print('ON LOAD FINISHED!');
// }
//
// void onMfa() async {
//   print('ON MULTI-FACTOR AUTHENTICATION!');
//   List<TwoFaProviderInfo> providers = await tbClient
//       .getTwoFactorAuthService()
//       .getAvailableLoginTwoFaProviders();
//   print('Available providers: $providers');
//   var defaultProvider =
//   providers.firstWhereOrNull((provider) => provider.isDefault);
//   if (defaultProvider != null) {
//     print('Default provider: $defaultProvider');
//     await tbClient
//         .getTwoFactorAuthService()
//         .requestTwoFaVerificationCode(defaultProvider.type);
//     print('Verification code sent!');
//     print('Enter MFA code:');
//     var code = stdin.readLineSync(encoding: utf8);
//     var mfaCode = code?.trim();
//     print('Code entered: $mfaCode');
//     await tbClient.checkTwoFaVerificationCode(defaultProvider.type, mfaCode!);
//   } else {
//     await tbClient.logout();
//   }
// }

const username = 'tenantdemo@thingsboard.org';
const password = 'tenant';
late ThingsboardClient tbClient;
bool loginExecuted = false;

Future<void> onUserLoaded() async {
  print("onUserLoad is working");
  try {
    print('onUserLoaded: isAuthenticated=${tbClient.isAuthenticated()}');
    if (tbClient.isAuthenticated() && !tbClient.isPreVerificationToken()) {
      print('ThingsBoard Platform Version: ${tbClient.getPlatformVersion()}');
      print('authUser: ${tbClient.getAuthUser()}');
      User? currentUser;
      try {
        currentUser = await tbClient.getUserService().getUser();
      } catch (e) {
        await tbClient.logout();
      }
      print('currentUser: $currentUser');
      if (tbClient.isSystemAdmin()) {
        await fetchSettingsExample();
      } else if (tbClient.isTenantAdmin()) {
        await fetchAlarmsExample();
      } else if (tbClient.isCustomerUser()) {
        await fetchAlarmsExample();
      }
      await tbClient.logout(
          requestConfig:
          RequestConfig(ignoreLoading: true, ignoreErrors: true));
    } else {
      if (!loginExecuted) {
        loginExecuted = true;
        await tbClient.login(LoginRequest(username, password));
      }
    }
  } catch (e, s) {
    print('Error: $e');
    print('Stack: $s');
  }
}

Future<void> fetchSettingsExample() async {
  print(
      '**********************************************************************');
  print(
      '*                      FETCH SETTINGS EXAMPLE                         *');
  print(
      '**********************************************************************');

  var settings = await tbClient.getAdminService().getAdminSettings('general');
  print('General settings: ${settings?.generalSettings}');

  settings = await tbClient.getAdminService().getAdminSettings('mail');
  print('Email settings: ${settings?.mailServerSettings}');

  settings = await tbClient.getAdminService().getAdminSettings('sms');
  print('SMS settings: ${settings?.smsProviderConfiguration}');

  var securitySettings = await tbClient.getAdminService().getSecuritySettings();
  print('Security settings: $securitySettings');

  var updateMessage = await tbClient.getAdminService().checkUpdates();
  print('Updates: $updateMessage');

  print(
      '**********************************************************************');
}

Future<void> fetchAlarmsExample() async {
  print(
      '**********************************************************************');
  print(
      '*                        FETCH ALARMS LIST                            *');
  print(
      '**********************************************************************');

  var alarmQuery = AlarmQuery(
      TimePageLink(10, 0, null, SortOrder('createdTime', Direction.DESC)),
      fetchOriginator: true);
  PageData<AlarmInfo> alarms;
  var total = 0;
  do {
    alarms = await tbClient.getAlarmService().getAllAlarms(alarmQuery);
    total += alarms.data.length;
    print('alarms: $alarms');
    alarmQuery.pageLink = alarmQuery.pageLink.nextPageLink();
  } while (alarms.hasNext && total <= 50);
  print(
      '**********************************************************************');
}

Future<void> fetchTenantDevicesExample() async {
  print(
      '**********************************************************************');
  print(
      '*                 FETCH TENANT DEVICES LIST                           *');
  print(
      '**********************************************************************');

  var pageLink = PageLink(10);
  PageData<DeviceInfo> devices;
  do {
    devices = await tbClient.getDeviceService().getTenantDeviceInfos(pageLink);
    print('devices: $devices');
    pageLink = pageLink.nextPageLink();
  } while (devices.hasNext);
  print(
      '**********************************************************************');
}

void importDashboard() {
  const  jsonFilePath = 'C:/Users/Admin/AndroidStudioProjects/thingsboard_simulation/lib/home.json';
  try {
    print("working line no.822 ");
    // Step 1: Open the JSON file
    final File jsonFile = File(jsonFilePath);
    final String jsonString = jsonFile.readAsStringSync();

    // Step 2: Parse the JSON string into a Map
    Map<String, dynamic> jsonMap = jsonDecode(jsonString);

    // Step 3: Connect to Thingsboard
    var tbClient = ThingsboardClient('http://phyclouds.com:8080');
    tbClient.login(LoginRequest('tenantdemo@thingsboard.org', 'tenant'));

    // Step 4: Create the dashboard
    var dashboard = Dashboard('Home_demo');
    dashboard.title = jsonMap['title'] as String;
    dashboard.configuration = jsonMap['configuration'];

    // Step 5: Save the dashboard
    var dashboardId = tbClient
        .getDashboardService()
        .saveDashboard(dashboard as Dashboard);
    // var dashId = await tbClient.getDashboardService().saveDashboard(dashboard);

    // Step 6: Print the created dashboard ID
    print('Dashboard created with ID:');

    // Step 7: Disconnect from Thingsboard
    // await tbClient.logout();
  } catch (e) {
    print('Error: $e');
  }
  print("COMPLETE");
}

void importDashboard2() {
  try {
    print("check importDashboard2");
    // Step 1: Open the JSON file
    final File jsonFile = File('C:/Users/Admin/AndroidStudioProjects/thingsboard_simulation/lib/home.json');
    final String jsonString = jsonFile.readAsStringSync();
    // print(jsonString);
    // Step 2: Parse the JSON string into a Map
    Map<String, dynamic> jsonMap = jsonDecode(jsonString);
    print("check importDashboard2");

    // Step 3: Connect to Thingsboard
    var tbClient = ThingsboardClient('http://phyclouds.com:8080');
    tbClient.login(LoginRequest('tenantdemo@thingsboard.org', 'tenant'));

    // Step 4: Create the dashboard
    var dashboard = Dashboard('test_board');
    dashboard.title = jsonMap['title'] as String;
    dashboard.configuration = jsonMap['configuration'];

    // Step 5: Save the dashboard
    // var dashboardId = tbClient
    //     .getDashboardService()
    //     .saveDashboard(dashboard as Dashboard);
    var dashId = tbClient.getDashboardService().saveDashboard(dashboard);

    // Step 6: Print the created dashboard ID
    print('Dashboard created with ID:');

    // Step 7: Disconnect from Thingsboard
    tbClient.logout();
  } catch (e) {
    print('Error: $e');
  }
  print("COMPLETE");
}

Future<Map<String, dynamic>> readJsonFile(String filePath) async {
  File file = File(filePath);
  if (await file.exists()) {
    String contents = await file.readAsString();
    return jsonDecode(contents);
  } else {
    throw Exception('File not found');
  }
}

Future<void> writeJsonFile(
    String filePath, Map<String, dynamic> jsonData) async {
  File file = File(filePath);
  await file.writeAsString(jsonEncode(jsonData));
}

void importDashboard3() async {
  try {
    print('Enter the Number(Take in 1 or 4 no.) of switch you want:');
    String? widget = stdin.readLineSync();

    var tbClient = ThingsboardClient('http://phyclouds.com:8080');
    await tbClient.login(LoginRequest('tenantdemo@thingsboard.org', 'tenant'));

    print('step 1');
    if (widget == '4') {
      String filePath =
          'C:/Users/Admin/AndroidStudioProjects/thingsboard_simulation/lib/home.json'; // Replace with the actual file path

      // Read the JSON file
      Map<String, dynamic> jsonData = await readJsonFile(filePath);

      print("Enter a new dashboard name:");
      String? newDash = stdin.readLineSync();
      var dashboard = Dashboard(newDash!);
      // Get user input for the new title
      print('Enter the new title:');
      String? newTitle = stdin.readLineSync();

      // Modify the title in the JSON data
      jsonData['title'] = newTitle;

      // dashboard.title = jsonData['title'] as String;
      dashboard.configuration = jsonData['configuration'];

      // Write the updated JSON data back to the file
      await writeJsonFile2(filePath, jsonData);
      print('Title updated successfully.');
      var dashboardId = await tbClient
          .getDashboardService()
          .saveDashboard(dashboard as Dashboard);

      // Step 6: Print the created dashboard ID
      print('Dashboard created with ID: ${dashboardId.id}');
    } else {
      String filePath2 =
          'C:/Users/Admin/AndroidStudioProjects/thingsboard_simulation/lib/home1.json'; // Replace with the actual file path

      // Read the JSON file
      Map<String, dynamic> jsonData2 = await readJsonFile(filePath2);

      print("Enter a new dashboard name:");
      String? newDash = stdin.readLineSync();
      var dashboard = Dashboard(newDash!);
      // Get user input for the new title
      print('Enter the new title:');
      String? newTitle = stdin.readLineSync();
      // print('Enter the new Description:');
      // String? newDescription = stdin.readLineSync();
      // print('Enter the new Name:');
      // String? newName = stdin.readLineSync();

      // Modify the title in the JSON data
      jsonData2['title'] = newTitle;

      // dashboard.title = jsonData['title'] as String;
      dashboard.configuration = jsonData2['configuration'];

      // Write the updated JSON data back to the file
      await writeJsonFile2(filePath2, jsonData2);
      print('Title updated successfully.');
      var dashboardId = await tbClient
          .getDashboardService()
          .saveDashboard(dashboard as Dashboard);

      // Print the created dashboard ID
      print('Dashboard created with ID: ${dashboardId.id}');
    }

    await tbClient.logout();
  } catch (e) {
    print('Error: $e');
  }
  print("COMPLETE");
}

// Future<Map<String, dynamic>> readJsonFile2(String filePath) async {
//   File file = File(filePath);
//   if (await file.exists()) {
//     String contents = await file.readAsString();
//     return jsonDecode(contents);
//   } else {
//     throw Exception('File not found');
//   }
// }

Future<void> writeJsonFile2(
    String filePath, Map<String, dynamic> jsonData) async {
  File file = File(filePath);
  await file.writeAsString(jsonEncode(jsonData));
}



//
// import 'dart:io';
//
// import 'package:thingsboard_client/thingsboard_client.dart';
//
// void main() async {
//   // ThingsBoard REST API URL
//   const thingsBoardApiEndpoint = 'http://phyclouds.com:8080';
//
//   // Create a ThingsboardClient instance
//   final tbClient = ThingsboardClient(thingsBoardApiEndpoint);
//
//   // Prompt the user for input
//   print("Enter the name of the asset:");
//   final assetName = stdin.readLineSync();
//   print("Enter the name of the device:");
//   final deviceName = stdin.readLineSync();
//   print("Enter the alarm rule name:");
//   final alarmRuleName = stdin.readLineSync();
//
//   try {
//     // Perform login with your credentials
//     await tbClient.login(LoginRequest('tenantdemo@thingsboard.org', 'tenant'));
//
//     // Create an asset
//     final asset = Asset.fromJson({
//       'name': assetName,
//       // Add other asset attributes as needed
//     });
//
//     // Create a device
//     final device = Device.fromJson({
//       'name': deviceName,
//       // Add other device attributes as needed
//     });
//
//     // Create an alarm rule for the asset
//     final assetAlarmRule = Alarm.fromJson({
//       'name': alarmRuleName,
//       'severity': AlarmSeverity.CRITICAL, // Set the severity level as needed
//       'alarmType': 'CUSTOM', // Set the alarm type as needed
//       'assetId': asset.id!.id,
//       // Add other alarm rule attributes as needed
//     });
//
//     // Create an alarm rule for the device
//     final deviceAlarmRule = Alarm.fromJson({
//       'name': alarmRuleName,
//       'severity': AlarmSeverity.CRITICAL, // Set the severity level as needed
//       'alarmType': 'CUSTOM', // Set the alarm type as needed
//       'deviceId': device.id!.id,
//       // Add other alarm rule attributes as needed
//     });
//
//     // Save the asset and device with the alarm rules
//     final createdAsset = await tbClient.getAssetService().saveAsset(asset);
//     final createdDevice = await tbClient.getDeviceService().saveDevice(device);
//
//     // // Save the alarm rules
//     // final createdAssetAlarmRule = await tbClient.alarmService.createOrUpdateAlarmRule(assetAlarmRule);
//     // final createdDeviceAlarmRule = await tbClient.alarmService.createOrUpdateAlarmRule(deviceAlarmRule);
//     final createdAssetAlarmRule = await tbClient.getAlarmService().getAlarm(assetAlarmRule as String);
//     final createdDeviceAlarmRule = await tbClient.getAlarmService().getAlarm(deviceAlarmRule as String);
//
//     print('Asset created with ID: ${createdAsset.id}');
//     print('Device created with ID: ${createdDevice.id}');
//     print('Asset Alarm Rule created with ID: ${createdAssetAlarmRule?.id}');
//     print('Device Alarm Rule created with ID: ${createdDeviceAlarmRule?.id}');
//
//     // Logout
//     await tbClient.logout();
//   } catch (e) {
//     print('Error: $e');
//   }
// }