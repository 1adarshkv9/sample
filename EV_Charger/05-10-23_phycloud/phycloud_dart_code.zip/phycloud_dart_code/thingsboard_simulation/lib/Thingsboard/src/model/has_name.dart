abstract class HasName {
  String getName();
}
