class Constants {
  static const entryPoints = {
    'login': '/api/auth/login',
    'tokenRefresh': '/api/auth/token',
    'nonTokenBased': '/api/noauth'
  };
}
