import 'id/tenant_id.dart';

abstract class HasTenantId {
  TenantId? getTenantId();
}
