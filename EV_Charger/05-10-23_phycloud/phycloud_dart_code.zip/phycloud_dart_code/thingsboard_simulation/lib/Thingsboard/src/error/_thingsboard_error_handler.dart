import 'thingsboard_error.dart';

ThingsboardError toThingsboardError(error, [StackTrace? stackTrace]) =>
    throw UnsupportedError('');
