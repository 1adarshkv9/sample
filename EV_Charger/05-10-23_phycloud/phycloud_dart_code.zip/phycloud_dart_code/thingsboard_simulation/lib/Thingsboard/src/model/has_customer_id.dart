import 'id/customer_id.dart';

abstract class HasCustomerId {
  CustomerId? getCustomerId();
}
