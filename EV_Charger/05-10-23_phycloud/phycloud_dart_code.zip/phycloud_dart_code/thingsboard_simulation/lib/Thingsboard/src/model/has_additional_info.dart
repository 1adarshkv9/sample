abstract class HasAdditionalInfo {
  Map<String, dynamic>? getAdditionalInfo();
}
