import 'tb_storage.dart';

TbStorage createLocalFileStorage(String fileName, [String? path]) =>
    throw UnsupportedError('');
