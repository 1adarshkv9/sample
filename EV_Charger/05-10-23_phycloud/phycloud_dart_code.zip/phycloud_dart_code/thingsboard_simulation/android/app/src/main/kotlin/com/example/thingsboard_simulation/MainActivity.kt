package com.example.thingsboard_simulation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
