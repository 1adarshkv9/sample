THINGSBOARD(phyclouds.com:8080)


In dart language-
	
	-In yaml file use this package-
		  http: ^1.1.0
		  dio: ^4.0.6
                  web_socket_channel: ^2.2.0
                  jwt_decoder: ^2.0.1
	* Once you write this packages the use this two command 
		- pub upgrade
		- pub get
    
	- Then use Thiingsboard folder to use all functionality
	- check demo(thingsboard_simulation code).
	- first change user name password in code(main.dart) (username- tenantdemo@thingsboard.org and password- tenant)
	- run thingsboard_simulation\lib\main.dart
	
And you can check all result in (http://phyclouds.com:8080) and username-password is (tenantdemo@thingsboard, tenant)